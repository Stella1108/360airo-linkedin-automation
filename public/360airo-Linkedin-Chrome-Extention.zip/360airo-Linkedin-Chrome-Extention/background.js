// background.js - COMPLETE FIXED VERSION WITH SUPABASE
console.log('🚀 360airo LinkedIn Connector starting...');

// ========== SUPABASE SETUP ==========
let supabaseClient = null;

// Dynamic import for Supabase (ES Module compatible)
async function initSupabase() {
  if (!supabaseClient) {
    try {
      // Method 1: Try to import from CDN (if you're using bundler)
      if (typeof supabase !== 'undefined') {
        supabaseClient = supabase;
        console.log('✅ Supabase already available globally');
        return supabaseClient;
      }
      
      // Method 2: Use direct fetch to Supabase API
      // We'll use this method since importScripts doesn't work in Manifest V3
      supabaseClient = createSupabaseClient();
      console.log('✅ Supabase client initialized via direct API');
    } catch (error) {
      console.error('❌ Failed to initialize Supabase:', error);
      supabaseClient = null;
    }
  }
  return supabaseClient;
}

// Create Supabase client without importScripts
function createSupabaseClient() {
  const SUPABASE_URL = 'https://tlojcedldomndodmnjan.supabase.co';
  const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRsb2pjZWRsZG9tbmRvZG1uamFuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTIyMzcyMDYsImV4cCI6MjA2NzgxMzIwNn0.rM-5ap5sYqV9reVU6oVPY8Dn9xQCr5u3cW8RbWoo1W0';
  
  // Simple Supabase client using fetch API
  return {
    from: (table) => ({
      select: (columns = '*') => ({
        async then(callback) {
          try {
            const response = await fetch(`${SUPABASE_URL}/rest/v1/${table}?select=${columns}`, {
              headers: {
                'apikey': SUPABASE_ANON_KEY,
                'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
                'Content-Type': 'application/json'
              }
            });
            
            const data = await response.json();
            callback({ data, error: !response.ok ? new Error('Request failed') : null });
          } catch (error) {
            callback({ data: null, error });
          }
        }
      }),
      
      upsert: (data, options = {}) => ({
        async then(callback) {
          try {
            const method = options.onConflict ? 'PATCH' : 'POST';
            const url = `${SUPABASE_URL}/rest/v1/${table}`;
            
            const response = await fetch(url, {
              method,
              headers: {
                'apikey': SUPABASE_ANON_KEY,
                'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
                'Content-Type': 'application/json',
                'Prefer': 'resolution=merge-duplicates'
              },
              body: JSON.stringify(data)
            });
            
            const responseData = await response.json();
            callback({ 
              data: Array.isArray(responseData) ? responseData[0] : responseData, 
              error: !response.ok ? new Error('Upsert failed') : null 
            });
          } catch (error) {
            callback({ data: null, error });
          }
        }
      }),
      
      // Add other methods as needed
      insert: (data) => ({
        async then(callback) {
          try {
            const response = await fetch(`${SUPABASE_URL}/rest/v1/${table}`, {
              method: 'POST',
              headers: {
                'apikey': SUPABASE_ANON_KEY,
                'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
                'Content-Type': 'application/json',
                'Prefer': 'return=representation'
              },
              body: JSON.stringify(data)
            });
            
            const responseData = await response.json();
            callback({ 
              data: Array.isArray(responseData) ? responseData[0] : responseData, 
              error: !response.ok ? new Error('Insert failed') : null 
            });
          } catch (error) {
            callback({ data: null, error });
          }
        }
      })
    })
  };
}

// ========== ENCRYPTION FUNCTIONS ==========
function encryptData(data) {
  try {
    if (!data) return null;
    
    // Handle different data types
    let stringToEncrypt;
    if (typeof data === 'string') {
      stringToEncrypt = data;
    } else if (typeof data === 'object') {
      stringToEncrypt = JSON.stringify(data);
    } else {
      stringToEncrypt = String(data);
    }
    
    // Base64 encoding for basic obfuscation
    // Note: In production, use proper encryption like AES
    const encoded = encodeURIComponent(stringToEncrypt);
    const encrypted = btoa(encoded);
    
    console.log(`🔐 Encrypted ${stringToEncrypt.length} chars to ${encrypted.length} chars`);
    return encrypted;
    
  } catch (error) {
    console.error('Encryption error:', error);
    return null;
  }
}

function decryptData(encrypted) {
  try {
    if (!encrypted) return null;
    
    // Base64 decoding
    const decoded = atob(encrypted);
    const jsonString = decodeURIComponent(decoded);
    
    // Try to parse as JSON, return as string if it fails
    try {
      return JSON.parse(jsonString);
    } catch {
      return jsonString;
    }
    
  } catch (error) {
    console.error('Decryption error:', error);
    return null;
  }
}

// ========== STATE MANAGEMENT ==========
let connectedAccounts = new Map();
let recentlyProcessed = new Set();
let loginDetectionActive = true;

// Load accounts from storage
async function loadAccounts() {
  try {
    const storage = await chrome.storage.local.get(['linkedinAccounts']);
    if (storage.linkedinAccounts) {
      storage.linkedinAccounts.forEach(account => {
        connectedAccounts.set(account.profileId, account);
      });
      console.log(`📁 Loaded ${connectedAccounts.size} accounts from storage`);
    }
  } catch (error) {
    console.error('Error loading accounts:', error);
  }
}

// Save accounts to storage
async function saveAccounts() {
  try {
    const accounts = Array.from(connectedAccounts.values());
    await chrome.storage.local.set({ linkedinAccounts: accounts });
    console.log(`💾 Saved ${accounts.length} accounts to storage`);
    return true;
  } catch (error) {
    console.error('Error saving accounts:', error);
    return false;
  }
}

// ========== STORE ACCOUNT WITH LI_AT COOKIE ==========
async function storeAccountWithLiAt(profile, cookies, tabUrl) {
  try {
    console.log(`🔗 Storing account with li_at cookie...`);
    
    if (!cookies || !Array.isArray(cookies)) {
      throw new Error('No cookies provided');
    }
    
    // Find li_at cookie - CRITICAL FOR LINKEDIN AUTH
    const liAtCookie = cookies.find(c => c.name === 'li_at');
    
    if (!liAtCookie) {
      console.warn('⚠️ No li_at cookie found in provided cookies');
      console.log('Available cookies:', cookies.map(c => c.name));
      return { 
        success: false, 
        error: 'No li_at cookie found',
        stored: false 
      };
    }
    
    console.log(`✅ li_at cookie found: ${liAtCookie.value.length} characters`);
    
    const accountId = `acc_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
    const profileId = profile.profileId || `profile_${Date.now()}`;
    
    // Encrypt cookies before storing
    const encryptedCookies = encryptData(cookies);
    if (!encryptedCookies) {
      return { 
        success: false, 
        error: 'Failed to encrypt cookies',
        stored: false 
      };
    }
    
    // Create account object
    const newAccount = {
      id: accountId,
      profileId: profileId,
      name: profile.name || 'Unknown User',
      headline: profile.headline || '',
      company: profile.company || '',
      location: profile.location || '',
      connections: profile.connections || 0,
      profileImage: profile.profileImage || '',
      profileUrl: profile.profileUrl || tabUrl,
      cookies: encryptedCookies, // Store encrypted cookies
      hasLiAt: true,
      liAtLength: liAtCookie.value.length,
      liAtPreview: liAtCookie.value.substring(0, 15) + '...',
      connectedAt: new Date().toISOString(),
      lastSynced: new Date().toISOString(),
      isActive: true,
      status: 'connected',
      supabaseSynced: false,
      cookieCount: cookies.length,
      autoDetected: false
    };
    
    // Store locally
    connectedAccounts.set(profileId, newAccount);
    await saveAccounts();
    
    console.log(`✅ Account "${profile.name || 'Unknown'}" stored locally`);
    
    // Store to Supabase
    const supabaseResult = await storeToSupabase(accountId, profile, cookies);
    
    if (supabaseResult.success) {
      newAccount.supabaseSynced = true;
      newAccount.supabaseAccountId = supabaseResult.supabaseAccountId;
      newAccount.supabaseSessionId = supabaseResult.supabaseSessionId;
      await saveAccounts();
      console.log(`✅ Account "${profile.name || 'Unknown'}" stored to Supabase`);
    } else {
      console.log(`⚠️ Supabase storage failed: ${supabaseResult.error}`);
    }
    
    return {
      success: true,
      account: newAccount,
      supabaseResult: supabaseResult,
      stored: true
    };
    
  } catch (error) {
    console.error('❌ Error storing account:', error);
    return {
      success: false,
      error: error.message,
      stored: false
    };
  }
}

// ========== STORE TO SUPABASE - COMPLETE VERSION FOR ACCOUNTS + SESSIONS ==========
async function storeToSupabase(accountId, profileData, cookies) {
  try {
    console.log('📤 Storing to Supabase (Accounts + Sessions)...');
    
    // Find li_at cookie
    const liAtCookie = cookies.find(c => c.name === 'li_at');
    if (!liAtCookie) {
      console.error('❌ No li_at cookie found for Supabase storage');
      return { success: false, error: 'No li_at cookie for Supabase' };
    }
    
    console.log(`✅ Found li_at cookie: ${liAtCookie.value.length} chars`);
    
    // Get or create user ID
    const storage = await chrome.storage.local.get(['extensionUserId']);
    let userId = storage.extensionUserId;
    if (!userId) {
      userId = `user_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      await chrome.storage.local.set({ extensionUserId: userId });
      console.log(`👤 Created new user ID: ${userId}`);
    } else {
      console.log(`👤 Using existing user ID: ${userId}`);
    }
    
    // ========== STEP 1: STORE ACCOUNT IN linkedin_accounts TABLE ==========
    const accountData = {
      user_id: userId,
      extension_account_id: accountId,
      profile_id: profileData.profileId || `profile_${Date.now()}`,
      name: profileData.name ? profileData.name.replace(/\s+/g, ' ').trim().substring(0, 255) : 'Unknown User',
      headline: profileData.headline ? profileData.headline.substring(0, 500) : '',
      company: profileData.company ? profileData.company.substring(0, 255) : '',
      location: profileData.location ? profileData.location.substring(0, 255) : '',
      connections: parseInt(profileData.connections) || 0,
      profile_image_url: profileData.profileImage ? profileData.profileImage.substring(0, 1000) : '',
      profile_url: profileData.profileUrl ? profileData.profileUrl.substring(0, 1000) : '',
      is_active: true,
      status: 'connected',
      has_li_at: true,
      li_at_preview: liAtCookie.value.substring(0, 20),
      cookie_count: cookies.length,
      last_synced: new Date().toISOString(),
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    
    console.log('📝 Account data prepared for Supabase:', {
      name: accountData.name,
      profile_id: accountData.profile_id,
      cookie_count: accountData.cookie_count,
      has_li_at: accountData.has_li_at
    });
    
    // First, try to check if account already exists
    const checkExistingResponse = await fetch(
      `https://tlojcedldomndodmnjan.supabase.co/rest/v1/linkedin_accounts?extension_account_id=eq.${accountId}&select=id`,
      {
        headers: {
          'apikey': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRsb2pjZWRsZG9tbmRvZG1uamFuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTIyMzcyMDYsImV4cCI6MjA2NzgxMzIwNn0.rM-5ap5sYqV9reVU6oVPY8Dn9xQCr5u3cW8RbWoo1W0',
          'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRsb2pjZWRsZG9tbmRvZG1uamFuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTIyMzcyMDYsImV4cCI6MjA2NzgxMzIwNn0.rM-5ap5sYqV9reVU6oVPY8Dn9xQCr5u3cW8RbWoo1W0'
        }
      }
    );
    
    let supabaseAccountId;
    let existingAccounts = [];
    
    if (checkExistingResponse.ok) {
      existingAccounts = await checkExistingResponse.json();
      console.log('🔍 Existing accounts check:', existingAccounts);
    }
    
    // Use POST (insert) or PATCH (update) based on existence
    const accountMethod = existingAccounts.length > 0 ? 'PATCH' : 'POST';
    const accountUrl = existingAccounts.length > 0 
      ? `https://tlojcedldomndodmnjan.supabase.co/rest/v1/linkedin_accounts?extension_account_id=eq.${accountId}`
      : 'https://tlojcedldomndodmnjan.supabase.co/rest/v1/linkedin_accounts';
    
    console.log(`🔄 Using ${accountMethod} for account storage`);
    
    const accountResponse = await fetch(accountUrl, {
      method: accountMethod,
      headers: {
        'apikey': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRsb2pjZWRsZG9tbmRvZG1uamFuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTIyMzcyMDYsImV4cCI6MjA2NzgxMzIwNn0.rM-5ap5sYqV9reVU6oVPY8Dn9xQCr5u3cW8RbWoo1W0',
        'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRsb2pjZWRsZG9tbmRvZG1uamFuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTIyMzcyMDYsImV4cCI6MjA2NzgxMzIwNn0.rM-5ap5sYqV9reVU6oVPY8Dn9xQCr5u3cW8RbWoo1W0',
        'Content-Type': 'application/json',
        'Prefer': accountMethod === 'POST' ? 'return=representation' : 'return=representation'
      },
      body: JSON.stringify(accountData)
    });
    
    if (!accountResponse.ok) {
      const errorText = await accountResponse.text();
      console.error('❌ Account storage failed:', errorText);
      return { 
        success: false, 
        error: `Account storage failed: ${accountResponse.status} ${errorText}` 
      };
    }
    
    const accountResult = await accountResponse.json();
    console.log('✅ Account saved to Supabase:', accountResult);
    
    // Get the account ID from response
    if (Array.isArray(accountResult) && accountResult.length > 0) {
      supabaseAccountId = accountResult[0].id;
    } else if (accountResult.id) {
      supabaseAccountId = accountResult.id;
    } else {
      // If we can't get the ID from response, try to fetch it
      const fetchAccountIdResponse = await fetch(
        `https://tlojcedldomndodmnjan.supabase.co/rest/v1/linkedin_accounts?extension_account_id=eq.${accountId}&select=id`,
        {
          headers: {
            'apikey': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRsb2pjZWRsZG9tbmRvZG1uamFuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTIyMzcyMDYsImV4cCI6MjA2NzgxMzIwNn0.rM-5ap5sYqV9reVU6oVPY8Dn9xQCr5u3cW8RbWoo1W0',
            'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRsb2pjZWRsZG9tbmRvZG1uamFuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTIyMzcyMDYsImV4cCI6MjA2NzgxMzIwNn0.rM-5ap5sYqV9reVU6oVPY8Dn9xQCr5u3cW8RbWoo1W0'
          }
        }
      );
      
      if (fetchAccountIdResponse.ok) {
        const accountData = await fetchAccountIdResponse.json();
        if (accountData.length > 0) {
          supabaseAccountId = accountData[0].id;
        }
      }
    }
    
    if (!supabaseAccountId) {
      console.error('❌ Could not get Supabase account ID');
      return { 
        success: false, 
        error: 'Could not retrieve account ID from Supabase' 
      };
    }
    
    console.log(`✅ Got Supabase account ID: ${supabaseAccountId}`);
    
    // ========== STEP 2: STORE SESSION COOKIES IN linkedin_sessions TABLE ==========
    
    // Encrypt cookies for secure storage
    const encryptedLiAt = encryptData(liAtCookie.value);
    const encryptedCookies = encryptData(cookies);
    
    if (!encryptedLiAt || !encryptedCookies) {
      console.error('❌ Failed to encrypt cookies for session storage');
      return { 
        success: false, 
        error: 'Cookie encryption failed',
        supabaseAccountId: supabaseAccountId 
      };
    }
    
    // Prepare session data
    const sessionData = {
      account_id: supabaseAccountId,
      extension_account_id: accountId,
      li_at_cookie: encryptedLiAt,
      cookies_encrypted: encryptedCookies,
      browser_agent: navigator.userAgent.substring(0, 500),
      last_used: new Date().toISOString(),
      is_active: true,
      cookie_count: cookies.length,
      has_li_at: true,
      li_at_length: liAtCookie.value.length,
      li_at_preview: liAtCookie.value.substring(0, 15) + '...',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };
    
    console.log('🍪 Session data prepared:', {
      account_id: sessionData.account_id,
      cookie_count: sessionData.cookie_count,
      li_at_length: sessionData.li_at_length,
      has_encrypted_cookies: !!sessionData.cookies_encrypted
    });
    
    // Check for existing session
    const checkSessionResponse = await fetch(
      `https://tlojcedldomndodmnjan.supabase.co/rest/v1/linkedin_sessions?account_id=eq.${supabaseAccountId}&select=id`,
      {
        headers: {
          'apikey': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRsb2pjZWRsZG9tbmRvZG1uamFuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTIyMzcyMDYsImV4cCI6MjA2NzgxMzIwNn0.rM-5ap5sYqV9reVU6oVPY8Dn9xQCr5u3cW8RbWoo1W0',
          'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRsb2pjZWRsZG9tbmRvZG1uamFuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTIyMzcyMDYsImV4cCI6MjA2NzgxMzIwNn0.rM-5ap5sYqV9reVU6oVPY8Dn9xQCr5u3cW8RbWoo1W0'
        }
      }
    );
    
    let existingSessions = [];
    if (checkSessionResponse.ok) {
      existingSessions = await checkSessionResponse.json();
      console.log('🔍 Existing sessions check:', existingSessions);
    }
    
    // Use POST (insert) or PATCH (update) for session
    const sessionMethod = existingSessions.length > 0 ? 'PATCH' : 'POST';
    const sessionUrl = existingSessions.length > 0
      ? `https://tlojcedldomndodmnjan.supabase.co/rest/v1/linkedin_sessions?account_id=eq.${supabaseAccountId}`
      : 'https://tlojcedldomndodmnjan.supabase.co/rest/v1/linkedin_sessions';
    
    console.log(`🔄 Using ${sessionMethod} for session storage`);
    
    const sessionResponse = await fetch(sessionUrl, {
      method: sessionMethod,
      headers: {
        'apikey': 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRsb2pjZWRsZG9tbmRvZG1uamFuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTIyMzcyMDYsImV4cCI6MjA2NzgxMzIwNn0.rM-5ap5sYqV9reVU6oVPY8Dn9xQCr5u3cW8RbWoo1W0',
        'Authorization': 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRsb2pjZWRsZG9tbmRvZG1uamFuIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTIyMzcyMDYsImV4cCI6MjA2NzgxMzIwNn0.rM-5ap5sYqV9reVU6oVPY8Dn9xQCr5u3cW8RbWoo1W0',
        'Content-Type': 'application/json',
        'Prefer': sessionMethod === 'POST' ? 'return=representation' : 'return=representation'
      },
      body: JSON.stringify(sessionData)
    });
    
    if (!sessionResponse.ok) {
      const errorText = await sessionResponse.text();
      console.error('❌ Session storage failed:', errorText);
      return { 
        success: false, 
        error: `Session storage failed: ${sessionResponse.status} ${errorText}`,
        supabaseAccountId: supabaseAccountId 
      };
    }
    
    const sessionResult = await sessionResponse.json();
    console.log('✅ Session saved to Supabase:', sessionResult);
    
    // Get session ID
    let supabaseSessionId;
    if (Array.isArray(sessionResult) && sessionResult.length > 0) {
      supabaseSessionId = sessionResult[0].id;
    } else if (sessionResult.id) {
      supabaseSessionId = sessionResult.id;
    }
    
    console.log(`🎉 Successfully stored account and session to Supabase!`);
    console.log(`   Account ID: ${supabaseAccountId}`);
    console.log(`   Session ID: ${supabaseSessionId}`);
    console.log(`   Cookies stored: ${cookies.length}`);
    console.log(`   li_at length: ${liAtCookie.value.length} chars`);
    
    return {
      success: true,
      supabaseAccountId: supabaseAccountId,
      supabaseSessionId: supabaseSessionId,
      liAtLength: liAtCookie.value.length,
      cookiesEncrypted: true,
      accountStored: true,
      sessionStored: true,
      message: 'Account and session stored successfully in Supabase'
    };
    
  } catch (error) {
    console.error('❌ Supabase storage error:', error);
    return { 
      success: false, 
      error: error.message,
      stack: error.stack 
    };
  }
}

// ========== AUTO-DETECT LINKEDIN ACCOUNTS ==========
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  // Only process LinkedIn pages and when page is complete
  if (!loginDetectionActive || changeInfo.status !== 'complete' || !tab.url?.includes('linkedin.com')) {
    return;
  }
  
  // Skip login pages
  if (tab.url.includes('/login') || tab.url.includes('/uas/login')) {
    console.log('⏭️ Skipping login page');
    return;
  }
  
  console.log('🌐 LinkedIn page loaded:', tab.url);
  
  // Wait for page to fully load
  setTimeout(async () => {
    try {
      console.log('🔍 Checking for LinkedIn account...');
      
      // CRITICAL FIX: Get cookies DIRECTLY from Chrome API in background
      const cookies = await new Promise((resolve) => {
        chrome.cookies.getAll({ domain: '.linkedin.com' }, (cookies) => {
          if (chrome.runtime.lastError) {
            console.log('Cookie API error:', chrome.runtime.lastError.message);
            resolve([]);
          } else {
            resolve(cookies || []);
          }
        });
      });
      
      console.log(`🍪 Background got ${cookies.length} cookies from Chrome API`);
      
      // Check for li_at cookie
      const liAtCookie = cookies.find(c => c.name === 'li_at');
      if (!liAtCookie) {
        console.log('❌ No li_at cookie found in background check');
        return;
      }
      
      console.log(`✅ li_at cookie found in background: ${liAtCookie.value.length} chars`);
      
      // Get profile from content script
      const response = await chrome.tabs.sendMessage(tabId, {
        action: 'GET_CURRENT_PROFILE'
      }).catch(() => {
        console.log('⚠️ Content script not responding');
        return null;
      });
      
      if (!response) {
        console.log('⚠️ No response from content script');
        return;
      }
      
      console.log('📊 Profile check result:', {
        isLoggedIn: response.isLoggedIn,
        hasLiAt: response.hasLiAt,
        profileName: response.profile?.name,
        cookieCount: response.cookies?.length
      });
      
      if (!response.isLoggedIn || !response.profile) {
        console.log('⚠️ Not logged in or no profile');
        return;
      }
      
      const profile = response.profile;
      const profileId = profile.profileId;
      
      if (!profileId) {
        console.log('⚠️ No profile ID');
        return;
      }
      
      // Check if recently processed (prevent duplicates)
      if (recentlyProcessed.has(profileId)) {
        console.log(`⏭️ Skipping ${profile.name} - recently processed`);
        return;
      }
      
      recentlyProcessed.add(profileId);
      setTimeout(() => recentlyProcessed.delete(profileId), 30000);
      
      // Check if account already exists
      const existingAccount = connectedAccounts.get(profileId);
      if (existingAccount) {
        console.log(`✅ ${profile.name} already connected`);
        
        // Update last active time
        existingAccount.lastSynced = new Date().toISOString();
        await saveAccounts();
        
        // Notify popup
        chrome.runtime.sendMessage({
          action: 'EXISTING_ACCOUNT_DETECTED',
          account: {
            id: existingAccount.id,
            name: existingAccount.name,
            profileId: existingAccount.profileId
          }
        }).catch(() => {});
        
        return;
      }
      
      console.log(`🔗 New user detected: ${profile.name}`);
      
      // Store account with li_at cookie (from background API)
      const result = await storeAccountWithLiAt(profile, cookies, tab.url);
      
      if (result.success && result.stored) {
        console.log(`✅ Successfully stored: ${profile.name}`);
        
        // Mark as auto-detected
        result.account.autoDetected = true;
        await saveAccounts();
        
        // Send notification to popup
        try {
          await chrome.runtime.sendMessage({
            action: 'ACCOUNT_ADDED',
            account: result.account
          });
          console.log('📨 Notified popup about new account');
        } catch (error) {
          console.log('⚠️ Popup not open');
        }
        
        // Show browser notification
        chrome.notifications.create({
          type: 'basic',
          iconUrl: 'icons/icon128.png',
          title: '✅ LinkedIn Account Connected',
          message: `"${profile.name}" has been automatically connected`
        });
        
      } else {
        console.log(`⚠️ Failed to store: ${profile.name}`, result.error);
      }
      
    } catch (error) {
      console.error('❌ Auto-detection error:', error);
    }
  }, 3000);
});

// ========== MESSAGE HANDLER ==========
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('📨 Background received:', request.action);
  
  switch (request.action) {
    case 'GET_ACCOUNTS':
      try {
        const accounts = Array.from(connectedAccounts.values()).map(account => ({
          id: account.id,
          profileId: account.profileId,
          name: account.name,
          headline: account.headline,
          company: account.company,
          location: account.location,
          connections: account.connections,
          profileImage: account.profileImage,
          profileUrl: account.profileUrl,
          hasLiAt: account.hasLiAt,
          liAtLength: account.liAtLength,
          liAtPreview: account.liAtPreview,
          connectedAt: account.connectedAt,
          lastSynced: account.lastSynced,
          isActive: account.isActive,
          status: account.status,
          supabaseSynced: account.supabaseSynced,
          cookieCount: account.cookieCount,
          autoDetected: account.autoDetected || false,
          hasCookies: !!account.cookies
        }));
        
        console.log(`📤 Sending ${accounts.length} accounts to popup`);
        
        sendResponse({ 
          success: true, 
          accounts: accounts, 
          total: accounts.length 
        });
      } catch (error) {
        console.error('Error in GET_ACCOUNTS:', error);
        sendResponse({ 
          success: false, 
          error: error.message,
          accounts: [] 
        });
      }
      return true;
      
    case 'GET_CURRENT_SESSION':
      (async () => {
        try {
          const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
          if (!tabs.length) {
            sendResponse({ success: false, connected: false });
            return;
          }
          
          const response = await chrome.tabs.sendMessage(tabs[0].id, {
            action: 'GET_CURRENT_PROFILE'
          }).catch(() => null);
          
          if (response?.isLoggedIn && response.profile) {
            const existingAccount = connectedAccounts.get(response.profile.profileId);
            
            sendResponse({
              success: true,
              connected: true,
              profile: response.profile,
              hasLiAt: response.hasLiAt,
              alreadyConnected: !!existingAccount,
              existingAccount: existingAccount ? {
                id: existingAccount.id,
                name: existingAccount.name,
                profileId: existingAccount.profileId,
                hasLiAt: existingAccount.hasLiAt,
                supabaseSynced: existingAccount.supabaseSynced
              } : null
            });
          } else {
            sendResponse({
              success: true,
              connected: false,
              message: 'Not logged into LinkedIn'
            });
          }
        } catch (error) {
          sendResponse({ 
            success: false, 
            connected: false, 
            error: error.message 
          });
        }
      })();
      return true;
      
    case 'CONNECT_CURRENT_ACCOUNT':
      (async () => {
        try {
          const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
          if (!tabs.length) {
            sendResponse({ success: false, error: 'No active tab' });
            return;
          }
          
          const tab = tabs[0];
          
          // CRITICAL: Get cookies from Chrome API (background script CAN access this)
          const cookies = await new Promise((resolve) => {
            chrome.cookies.getAll({ domain: '.linkedin.com' }, (cookies) => {
              if (chrome.runtime.lastError) {
                console.error('Cookie error:', chrome.runtime.lastError);
                resolve([]);
              } else {
                resolve(cookies || []);
              }
            });
          });
          
          console.log(`🍪 Got ${cookies.length} LinkedIn cookies from background`);
          
          // Check for li_at cookie
          const liAtCookie = cookies.find(c => c.name === 'li_at');
          if (!liAtCookie) {
            console.log('❌ No li_at cookie found');
            sendResponse({ 
              success: false, 
              error: 'No li_at cookie found. Make sure you are logged into LinkedIn and refresh the page.' 
            });
            return;
          }
          
          console.log(`✅ li_at found: ${liAtCookie.value.length} chars`);
          
          // Get profile from content script
          const profileResponse = await chrome.tabs.sendMessage(tab.id, {
            action: 'GET_CURRENT_PROFILE'
          }).catch(() => null);
          
          if (!profileResponse?.profile) {
            sendResponse({ 
              success: false, 
              error: 'Could not extract profile information. Make sure you are on a LinkedIn profile page.' 
            });
            return;
          }
          
          const profile = profileResponse.profile;
          const profileId = profile.profileId;
          
          // Check if already exists
          const existingAccount = connectedAccounts.get(profileId);
          if (existingAccount) {
            sendResponse({ 
              success: false, 
              error: 'Account already connected',
              account: {
                id: existingAccount.id,
                name: existingAccount.name,
                profileId: existingAccount.profileId
              }
            });
            return;
          }
          
          // Store the account
          const result = await storeAccountWithLiAt(profile, cookies, tab.url);
          
          if (result.success && result.stored) {
            result.account.autoDetected = false;
            await saveAccounts();
            
            sendResponse({ 
              success: true, 
              account: {
                id: result.account.id,
                name: result.account.name,
                profileId: result.account.profileId,
                hasLiAt: result.account.hasLiAt,
                supabaseSynced: result.account.supabaseSynced
              },
              message: `Connected ${result.account.name} successfully!`
            });
          } else {
            sendResponse({ 
              success: false, 
              error: result.error || 'Failed to store account' 
            });
          }
          
        } catch (error) {
          console.error('Connect error:', error);
          sendResponse({ success: false, error: error.message });
        }
      })();
      return true;
      
    case 'SYNC_ACCOUNT_TO_SUPABASE':
      (async () => {
        try {
          const account = Array.from(connectedAccounts.values())
            .find(a => a.id === request.accountId);
          
          if (!account) {
            sendResponse({ success: false, error: 'Account not found' });
            return;
          }
          
          // Get decrypted cookies
          let cookies = [];
          if (account.cookies) {
            cookies = decryptData(account.cookies) || [];
          }
          
          if (cookies.length === 0) {
            sendResponse({ success: false, error: 'No cookies to sync' });
            return;
          }
          
          const profile = {
            profileId: account.profileId,
            name: account.name,
            headline: account.headline,
            company: account.company,
            location: account.location,
            connections: account.connections,
            profileImage: account.profileImage,
            profileUrl: account.profileUrl
          };
          
          const result = await storeToSupabase(account.id, profile, cookies);
          
          if (result.success) {
            account.supabaseSynced = true;
            account.lastSynced = new Date().toISOString();
            account.supabaseAccountId = result.supabaseAccountId;
            account.supabaseSessionId = result.supabaseSessionId;
            await saveAccounts();
            
            sendResponse({ 
              success: true, 
              message: 'Synced to Supabase'
            });
          } else {
            sendResponse({ 
              success: false, 
              error: result.error 
            });
          }
          
        } catch (error) {
          sendResponse({ success: false, error: error.message });
        }
      })();
      return true;
      
    case 'REMOVE_ACCOUNT':
      (async () => {
        try {
          const account = Array.from(connectedAccounts.values())
            .find(a => a.id === request.accountId);
          
          if (account) {
            connectedAccounts.delete(account.profileId);
            await saveAccounts();
            sendResponse({ 
              success: true, 
              message: `Removed ${account.name}` 
            });
          } else {
            sendResponse({ success: false, error: 'Account not found' });
          }
        } catch (error) {
          sendResponse({ success: false, error: error.message });
        }
      })();
      return true;
      
    case 'DEBUG_COOKIE_STORAGE':
      (async () => {
        try {
          const account = Array.from(connectedAccounts.values())
            .find(a => a.id === request.accountId);
          
          if (account) {
            // Try to decrypt cookies to check li_at
            let liAtInfo = { hasLiAt: false, length: 0 };
            if (account.cookies) {
              const cookies = decryptData(account.cookies);
              if (cookies && Array.isArray(cookies)) {
                const liAtCookie = cookies.find(c => c.name === 'li_at');
                if (liAtCookie) {
                  liAtInfo = {
                    hasLiAt: true,
                    length: liAtCookie.value.length,
                    preview: liAtCookie.value.substring(0, 10) + '...'
                  };
                }
              }
            }
            
            sendResponse({ 
              success: true, 
              accountName: account.name,
              hasLiAt: account.hasLiAt,
              liAtLength: account.liAtLength || 0,
              liAtPreview: account.liAtPreview,
              cookieCount: account.cookieCount || 0,
              supabaseSynced: account.supabaseSynced || false,
              lastSynced: account.lastSynced || 'Never',
              storedEncrypted: !!account.cookies,
              autoDetected: account.autoDetected || false
            });
          } else {
            sendResponse({ success: false, error: 'Account not found' });
          }
        } catch (error) {
          sendResponse({ success: false, error: error.message });
        }
      })();
      return true;
      
    case 'TEST_CONNECTION':
      sendResponse({ 
        success: true, 
        message: 'Background service is running',
        accountsCount: connectedAccounts.size,
        loginDetectionActive: loginDetectionActive
      });
      return true;
      
    case 'GET_ACCOUNT_BY_ID':
      const account = Array.from(connectedAccounts.values())
        .find(a => a.id === request.accountId);
      
      if (account) {
        sendResponse({ 
          success: true, 
          account: {
            id: account.id,
            name: account.name,
            profileId: account.profileId,
            headline: account.headline,
            company: account.company,
            location: account.location,
            connections: account.connections,
            profileImage: account.profileImage,
            hasLiAt: account.hasLiAt,
            supabaseSynced: account.supabaseSynced,
            lastSynced: account.lastSynced,
            autoDetected: account.autoDetected || false
          }
        });
      } else {
        sendResponse({ success: false, error: 'Account not found' });
      }
      return true;
      
    case 'UPDATE_ACCOUNT_COOKIES':
      (async () => {
        try {
          const account = Array.from(connectedAccounts.values())
            .find(a => a.id === request.accountId);
          
          if (!account) {
            sendResponse({ success: false, error: 'Account not found' });
            return;
          }
          
          // Update cookies
          const encryptedCookies = encryptData(request.cookies);
          account.cookies = encryptedCookies;
          
          // Update li_at info
          const liAtCookie = request.cookies.find(c => c.name === 'li_at');
          if (liAtCookie) {
            account.hasLiAt = true;
            account.liAtLength = liAtCookie.value.length;
            account.liAtPreview = liAtCookie.value.substring(0, 15) + '...';
          }
          
          account.lastSynced = new Date().toISOString();
          await saveAccounts();
          
          sendResponse({ 
            success: true, 
            message: 'Cookies updated successfully' 
          });
        } catch (error) {
          sendResponse({ success: false, error: error.message });
        }
      })();
      return true;
      
    case 'UPDATE_ACCOUNT':
      (async () => {
        try {
          const account = Array.from(connectedAccounts.values())
            .find(a => a.id === request.accountId);
          
          if (!account) {
            sendResponse({ success: false, error: 'Account not found' });
            return;
          }
          
          // Update account properties
          Object.assign(account, request.updates);
          await saveAccounts();
          
          sendResponse({ 
            success: true, 
            message: 'Account updated successfully' 
          });
        } catch (error) {
          sendResponse({ success: false, error: error.message });
        }
      })();
      return true;
      
    case 'VALIDATE_COOKIES':
      (async () => {
        try {
          const account = Array.from(connectedAccounts.values())
            .find(a => a.id === request.accountId);
          
          if (!account) {
            sendResponse({ success: false, error: 'Account not found' });
            return;
          }
          
          // Get decrypted cookies
          let cookies = [];
          if (account.cookies) {
            cookies = decryptData(account.cookies) || [];
          }
          
          const liAtCookie = cookies.find(c => c.name === 'li_at');
          
          if (!liAtCookie) {
            sendResponse({ success: true, isValid: false, reason: 'No li_at cookie found' });
            return;
          }
          
          // Simple validation - check if cookie has expected length
          const isValid = liAtCookie.value && liAtCookie.value.length > 100;
          
          sendResponse({ 
            success: true, 
            isValid: isValid,
            liAtLength: liAtCookie.value.length
          });
          
        } catch (error) {
          sendResponse({ success: false, error: error.message });
        }
      })();
      return true;
      
    case 'AUTO_LOGIN_DETECTED':
      console.log('🔍 Auto login detected:', request.profile?.name);
      
      if (sender.tab) {
        // Process auto-detection
        setTimeout(async () => {
          try {
            const response = await chrome.tabs.sendMessage(sender.tab.id, {
              action: 'GET_CURRENT_PROFILE'
            }).catch(() => null);
            
            if (response?.isLoggedIn && response.profile) {
              const profile = response.profile;
              const profileId = profile.profileId;
              
              if (!recentlyProcessed.has(profileId)) {
                recentlyProcessed.add(profileId);
                setTimeout(() => recentlyProcessed.delete(profileId), 30000);
                
                const existingAccount = connectedAccounts.get(profileId);
                if (!existingAccount) {
                  const cookies = await new Promise((resolve) => {
                    chrome.cookies.getAll({ domain: '.linkedin.com' }, (cookies) => {
                      if (chrome.runtime.lastError) {
                        resolve([]);
                      } else {
                        resolve(cookies || []);
                      }
                    });
                  });
                  
                  await storeAccountWithLiAt(profile, cookies, sender.tab.url);
                }
              }
            }
          } catch (error) {
            console.error('Auto-login processing error:', error);
          }
        }, 2000);
      }
      sendResponse({ success: true });
      return true;
  }
});

// Initialize on startup
(async () => {
  console.log('🚀 Background service initializing...');
  await loadAccounts();
  await initSupabase();
  console.log('✅ Background service ready');
})();
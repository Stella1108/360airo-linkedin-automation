// content.js - COMPLETE WORKING VERSION (NO COOKIE API ERRORS)
console.log('🔧 360airo LinkedIn Connector content script LOADED on:', window.location.href);

// ========== INITIALIZATION ==========
let isInitialized = false;

function initializeContentScript() {
  if (isInitialized) return;
  
  if (window.location.hostname.includes('linkedin.com')) {
    console.log('🌐 Initializing on LinkedIn page...');
    isInitialized = true;
    
    // Test message sending
    setTimeout(() => {
      chrome.runtime.sendMessage({ 
        action: 'CONTENT_SCRIPT_READY',
        url: window.location.href,
        timestamp: new Date().toISOString()
      }, (response) => {
        if (chrome.runtime.lastError) {
          console.log('⚠️ Send error:', chrome.runtime.lastError.message);
        } else {
          console.log('✅ Content script ready message sent');
        }
      });
      
      // Start profile extraction
      checkAndExtractProfile();
    }, 2000);
  }
}

// ========== COOKIE EXTRACTION (DOCUMENT.COOKIE ONLY) ==========
function getLinkedInCookies() {
  try {
    console.log('🍪 Getting cookies from document.cookie...');
    
    const cookies = [];
    const cookieString = document.cookie;
    
    if (!cookieString) {
      console.log('⚠️ No cookies in document.cookie');
      return [];
    }
    
    // Parse cookies from document.cookie
    cookieString.split(';').forEach(cookie => {
      const trimmedCookie = cookie.trim();
      const equalsIndex = trimmedCookie.indexOf('=');
      
      if (equalsIndex > 0) {
        const name = trimmedCookie.substring(0, equalsIndex);
        const value = trimmedCookie.substring(equalsIndex + 1);
        
        if (name && value) {
          // Only check for li_at and important LinkedIn cookies
          if (name === 'li_at' || name === 'JSESSIONID' || name === 'bcookie' || name === 'lang') {
            cookies.push({
              name: name,
              value: decodeURIComponent(value),
              domain: window.location.hostname,
              path: '/',
              secure: window.location.protocol === 'https:',
              httpOnly: false,
              sameSite: 'lax',
              source: 'document'
            });
          }
        }
      }
    });
    
    // Check for li_at
    const liAtCookie = cookies.find(c => c.name === 'li_at');
    if (liAtCookie) {
      console.log(`🔐 li_at found in document.cookie: ${liAtCookie.value.length} chars`);
    } else {
      console.log('⚠️ No li_at cookie found in document.cookie');
    }
    
    console.log(`✅ Found ${cookies.length} cookies in document.cookie`);
    return cookies;
    
  } catch (error) {
    console.error('Cookie extraction error:', error);
    return [];
  }
}

// ========== SIMPLE COOKIE FUNCTION (ALIAS) ==========
function getLinkedInCookiesSimple() {
  return getLinkedInCookies(); // Just an alias
}

// ========== PROFILE EXTRACTION ==========
function extractProfileData() {
  try {
    const data = {
      name: '',
      headline: '',
      location: '',
      company: '',
      connections: 0,
      profileUrl: window.location.href,
      profileImage: '',
      profileId: '',
      timestamp: new Date().toISOString()
    };
    
    // Extract name
    const nameSelectors = [
      'h1.text-heading-xlarge',
      'h1.profile-top-card-person__name',
      'h1.top-card-layout__title',
      '.artdeco-entity-lockup__title',
      'h1[data-test-profile-identity-name]',
      '.profile-topcard-person-entity__name'
    ];
    
    for (const selector of nameSelectors) {
      const element = document.querySelector(selector);
      if (element && element.textContent) {
        data.name = element.textContent.trim();
        if (data.name) {
          console.log(`✅ Found name: ${data.name}`);
          break;
        }
      }
    }
    
    // Extract headline
    const headlineSelectors = [
      '.text-body-medium.break-words',
      '.profile-top-card-person__headline',
      '.top-card-layout__headline',
      '.mt1.t-18.t-black.t-normal'
    ];
    
    for (const selector of headlineSelectors) {
      const element = document.querySelector(selector);
      if (element && element.textContent) {
        data.headline = element.textContent.trim();
        if (data.headline) break;
      }
    }
    
    // Extract location
    const locationSelectors = [
      '.pv-top-card-section__location',
      '.profile-top-card-person__location',
      'span.t-16.t-black.t-normal.inline-block',
      '.top-card-layout__location'
    ];
    
    for (const selector of locationSelectors) {
      const element = document.querySelector(selector);
      if (element && element.textContent) {
        data.location = element.textContent.trim();
        if (data.location) break;
      }
    }
    
    // Extract company
    const companySelectors = [
      'div.pv-text-details__left-panel span:first-child',
      '.profile-top-card-person__current-company',
      '[data-test="current-company"]',
      '.top-card-layout__company'
    ];
    
    for (const selector of companySelectors) {
      const element = document.querySelector(selector);
      if (element && element.textContent) {
        data.company = element.textContent.trim().split('·')[0].trim();
        if (data.company) break;
      }
    }
    
    // Extract profile image
    const imageSelectors = [
      'img.pv-top-card-profile-picture__image',
      'img.profile-photo-edit__preview',
      'img[data-delayed-url*="profile-displayphoto"]',
      'img.top-card-profile-picture__image'
    ];
    
    for (const selector of imageSelectors) {
      const img = document.querySelector(selector);
      if (img) {
        const src = img.getAttribute('src') || img.getAttribute('data-delayed-url') || img.getAttribute('data-src');
        if (src && src.includes('http')) {
          data.profileImage = src;
          break;
        }
      }
    }
    
    // Generate profile ID
    if (data.name) {
      data.profileId = data.name.toLowerCase()
        .replace(/[^a-z0-9\s]/g, '')
        .trim()
        .replace(/\s+/g, '_')
        .substring(0, 50);
    } else if (window.location.href.includes('/in/')) {
      // Extract from URL
      const urlMatch = window.location.href.match(/\/in\/([^\/?]+)/);
      if (urlMatch) {
        data.profileId = urlMatch[1];
      } else {
        data.profileId = 'profile_' + Date.now();
      }
    } else {
      data.profileId = 'profile_' + Date.now();
    }
    
    console.log('📊 Extracted profile:', { 
      name: data.name, 
      profileId: data.profileId,
      company: data.company 
    });
    
    return data;
    
  } catch (error) {
    console.error('Profile extraction error:', error);
    return null;
  }
}

// ========== SIMPLE PROFILE FUNCTION (ALIAS) ==========
function extractProfileSimple() {
  return extractProfileData();
}

// ========== CHECK LOGIN STATUS ==========
function checkIfLoggedIn() {
  try {
    // Method 1: Check for li_at cookie in document.cookie
    const cookieString = document.cookie;
    const hasLiAtCookie = cookieString.includes('li_at=');
    
    // Method 2: Check LinkedIn UI elements
    const loggedInSelectors = [
      'nav.global-nav',
      '.global-nav__me',
      '.feed-identity-module',
      'button.global-nav__primary-link--icon',
      '.scaffold-layout__main',
      '.global-nav__me-photo',
      '.feed-identity-module__actor-meta'
    ];
    
    const isLoggedInUI = loggedInSelectors.some(selector => {
      const element = document.querySelector(selector);
      return element !== null;
    });
    
    const isLoggedIn = hasLiAtCookie || isLoggedInUI;
    console.log('🔐 Login check:', { 
      hasLiAtCookie: hasLiAtCookie, 
      isLoggedInUI: isLoggedInUI,
      isLoggedIn: isLoggedIn 
    });
    
    return isLoggedIn;
    
  } catch (error) {
    console.error('Login check error:', error);
    return false;
  }
}

// ========== SIMPLE LOGIN FUNCTION (ALIAS) ==========
function checkIfLoggedInSimple() {
  return checkIfLoggedIn();
}

// ========== MESSAGE HANDLER ==========
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('📨 Content script received:', request.action);
  
  switch (request.action) {
    case 'PING':
      sendResponse({ pong: true, timestamp: new Date().toISOString() });
      return true;
      
    case 'GET_CURRENT_PROFILE':
      (() => {
        try {
          console.log('🔍 Getting current profile...');
          
          // Check if logged in
          const isLoggedIn = checkIfLoggedIn();
          
          if (!isLoggedIn) {
            sendResponse({
              isLoggedIn: false,
              profile: null,
              cookies: [],
              hasLiAt: false,
              message: 'Not logged into LinkedIn'
            });
            return;
          }
          
          // Extract profile
          const profile = extractProfileData();
          
          if (!profile) {
            sendResponse({
              isLoggedIn: true,
              profile: null,
              cookies: [],
              hasLiAt: false,
              message: 'Could not extract profile'
            });
            return;
          }
          
          // Get cookies from document.cookie
          const cookies = getLinkedInCookies();
          const hasLiAt = cookies.some(c => c.name === 'li_at');
          
          console.log('📦 Sending profile data:', {
            name: profile.name,
            hasLiAt: hasLiAt,
            cookieCount: cookies.length
          });
          
          sendResponse({
            isLoggedIn: true,
            profile: profile,
            cookies: cookies,
            hasLiAt: hasLiAt,
            timestamp: new Date().toISOString(),
            url: window.location.href,
            cookieCount: cookies.length,
            liAtLength: hasLiAt ? cookies.find(c => c.name === 'li_at').value.length : 0
          });
          
        } catch (error) {
          console.error('GET_CURRENT_PROFILE error:', error);
          sendResponse({
            isLoggedIn: false,
            profile: null,
            cookies: [],
            hasLiAt: false,
            error: error.message
          });
        }
      })();
      return true;
      
    case 'FORCE_EXTRACT':
      const profile = extractProfileData();
      sendResponse({ profile: profile });
      return true;
      
    case 'CHECK_STATUS':
      const status = checkIfLoggedIn();
      sendResponse({ loggedIn: status });
      return true;
      
    case 'GET_PROFILE_DATA':
      const profileData = extractProfileData();
      sendResponse({ profile: profileData });
      return true;
      
    case 'CHECK_IF_LOGGED_IN':
      const loggedIn = checkIfLoggedIn();
      sendResponse({ loggedIn: loggedIn });
      return true;
      
    case 'SCRAPE_FULL_PROFILE_WITH_HTML':
      try {
        const profileData = extractProfileData();
        const htmlContent = document.documentElement.outerHTML;
        const cookies = getLinkedInCookies();
        
        sendResponse({
          success: true,
          data: {
            profileData: profileData,
            htmlContent: htmlContent.substring(0, 50000),
            cookies: cookies,
            timestamp: new Date().toISOString(),
            url: window.location.href
          }
        });
      } catch (error) {
        sendResponse({ success: false, error: error.message });
      }
      return true;
  }
});

// ========== PROFILE CHECK ==========
function checkAndExtractProfile() {
  try {
    console.log('🔍 Checking for profile...');
    
    const isLoggedIn = checkIfLoggedIn();
    if (!isLoggedIn) {
      console.log('⚠️ Not logged in');
      return;
    }
    
    const profile = extractProfileData();
    if (!profile || !profile.name) {
      console.log('⚠️ No profile found');
      return;
    }
    
    const cookies = getLinkedInCookies();
    const hasLiAt = cookies.some(c => c.name === 'li_at');
    
    console.log('✅ Found profile:', profile.name);
    
    // Send to background
    chrome.runtime.sendMessage({
      action: 'PROFILE_SCRAPED',
      profile: profile,
      cookies: cookies,
      hasLiAt: hasLiAt,
      timestamp: new Date().toISOString(),
      url: window.location.href
    }, (response) => {
      if (chrome.runtime.lastError) {
        console.log('⚠️ Send to background error:', chrome.runtime.lastError.message);
      } else {
        console.log('✅ Profile sent to background');
      }
    });
    
  } catch (error) {
    console.error('Profile check error:', error);
  }
}

// ========== STARTUP ==========
// Initialize when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initializeContentScript);
} else {
  initializeContentScript();
}

// Also initialize on URL changes
let lastUrl = window.location.href;
const observer = new MutationObserver(() => {
  if (window.location.href !== lastUrl) {
    lastUrl = window.location.href;
    console.log('📍 URL changed to:', lastUrl);
    
    // Reset initialization for new page
    isInitialized = false;
    
    setTimeout(() => {
      initializeContentScript();
    }, 1000);
  }
});

observer.observe(document, { subtree: true, childList: true });

// Manual trigger after 3 seconds (fallback)
setTimeout(() => {
  if (!isInitialized && window.location.hostname.includes('linkedin.com')) {
    console.log('🔄 Manual initialization trigger');
    initializeContentScript();
  }
}, 3000);

console.log('✅ Content script loaded successfully');